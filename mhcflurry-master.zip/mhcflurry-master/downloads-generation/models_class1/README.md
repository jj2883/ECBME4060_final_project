# Class I allele-specific models (ensemble)

This download contains trained MHC Class I MHCflurry models.

To generate this download run:

```
./GENERATE.sh
```