# Downloads generation

This directory contains code and instructions needed to *generate* the datasets and trained models published with MHCflurry.

If you are only looking to download datasets and trained models, you do not need to use any of this. Just run `mhcflurry-downloads fetch` to download the standard models and datasets.