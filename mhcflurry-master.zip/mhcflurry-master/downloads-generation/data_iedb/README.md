# IEDB Data

This download is a snapshot of the IEDB MHC ligand data, available at:

http://www.iedb.org/doc/mhc_ligand_full.zip

To generate it, run:

```
./GENERATE.sh
```