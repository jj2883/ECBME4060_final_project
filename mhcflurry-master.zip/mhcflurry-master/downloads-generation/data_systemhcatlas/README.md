# SysteMHC database dump

This is a data dump of the [SysteMHC Atlas](https://systemhcatlas.org/) provided
by personal communication. It is distributed under the ODC Open Database License.

To generate this download run:

```
./GENERATE.sh
```