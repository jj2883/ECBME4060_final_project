.. _models_supported_alleles:

Supported alleles and peptide lengths
=====================================

.. include:: /_build/_models_supported_alleles.rst